# Módulo para configuraciones y llaves secretas
