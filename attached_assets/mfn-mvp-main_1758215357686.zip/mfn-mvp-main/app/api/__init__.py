# Módulo para APIs y conexiones a internet
