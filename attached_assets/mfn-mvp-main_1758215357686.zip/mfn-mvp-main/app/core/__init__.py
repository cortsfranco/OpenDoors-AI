# Módulo principal del cerebro y lógica de la aplicación
